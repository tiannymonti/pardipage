var cloneextend = require('cloneextend');
cloneextend.extend(this, require('./ss'));
cloneextend.extend(this, require('../dist/Numpy.js'));
cloneextend.extend(this, require('../dist/PolySolve.js'));
cloneextend.extend(this, require('../dist/Scipy.js'));
